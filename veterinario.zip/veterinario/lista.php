<?php
$con = mysqli_connect("localhost", "root", "", "veterinario");

if (!$con) {
    die("Erro na conexão: " . mysqli_connect_error());
}

$sql = "SELECT * FROM animal";
$resultado = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Lista de Animais</title>
</head>
<body>

<h1>Animais Cadastrados</h1>

<table border="1">
    <tr>
        <th>Nome</th>
        <th>Tutor</th>
    </tr>

    <?php
    while ($linha = mysqli_fetch_assoc($resultado)) {
        echo "<tr>";
        echo "<td>" . $linha['nome'] . "</td>";
        echo "<td>" . $linha['tutor'] . "</td>";
        echo "</tr>";
    }
    ?>
</table>

<br>
<a href="index.html">Voltar para cadastro</a>

</body>
</html>

<?php
mysqli_close($con);
?>