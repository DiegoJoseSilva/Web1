<?php
    $nome = $_GET["nome"];
    $tutor = $_GET ["tutor"];
    echo "Nome: $nome e Tutor: $tutor <br/><br/>";
    $con = mysqli_connect("localhost", "root", "", "veterinario");
    $sql = "INSERT INTO animal 
    (nome, tutor)
    VALUES ('$nome', '$tutor')";

    $resultado = mysqli_query($con, $sql);
?>