<?php
    include_once("ConnectionFactory_class.php"); //PDO
    include_once("Contato_class.php"); //Entidade

    class ContatoDAO{
        //DAO
        //CRUD
        //Operações básicas de banco de dados
        
        public $con = null;

        public function __construct(){
            $conF = new ConnectionFactory();
            $this->con = $conF->getConnection();
        }

        public function cadastrar($cont){
            try{
                $stmt = $this->con->prepare(
                    "INSERT INTO contato(nome, email, telefone, foto) VALUES (:nome, :email, :telefone, :foto)"
                );
                //ligamos as âncoras aos valores de contatos
                $stmt->bindValue(":nome", $cont->getNome());
                $stmt->bindValue(":email", $cont->getEmail());
                $stmt->bindValue(":telefone", $cont->getTelefone());
                $stmt->bindValue(":foto", "teste");

                 $stmt->execute(); //execução do SQL

                 /*this->con->close();
                 $this->con = null;*/
            }
            catch(PDOException $ex){
                echo "Erro: " . $ex->getMessage();
            }
        }

        public function alterar($cont){
            try{
                $stmt = $this->con->prepare(
                    "UPDATE contato SET nome=:nome, email = :email, telefone = :telefone, foto=:foto WHERE id=:id"
                );

                //ligamos as âncoras aos valores de Contato

                $stmt->bindValue(":nome", $cont->getNome());
                $stmt->bindValue(":email", $cont->getEmail());
                $stmt->bindValue(":telefone", $cont->getTelefone());
                $stmt->bindValue(":foto", $cont->getFoto());
                $stmt->bindValue(":id", $cont->getId());

                $this->con->beginTransaction();
                $stmt->execute();
                $this->con->commit();
                /*$this->con->close();
                $this->con=null;*/
            }
            catch(PDOException $ex){
                echo "Erro: " . $ex->getMessage();
            }
        }

        public function excluir($cont){
            try{
                $stmt = $this->con->prepare(
                    "DELETE FROM contato WHERE id = :id";
                );
                $stmt->bindValue(":id", $cont->getId());
                $stmt->Execute();
            }
            catch (PDOException $ex){
                echo "Erro: " . $ex->getMessage();
            }
        }
    }
?>