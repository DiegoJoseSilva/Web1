<?php
    class Contato{
        //Classe entidade

        private $id;
        private $nome;
        private $email;
        private $telefone;
        private $foto;

        public function __construct(){

        }

        public function setId($id){
            $this->id = $id;
        }

        public function getId(){
            return $this->id;
        }

        public function nome($nome){
            $this->nome = $nome;
        }

        public function getNome(){
            return $this->nome;
        }
    }