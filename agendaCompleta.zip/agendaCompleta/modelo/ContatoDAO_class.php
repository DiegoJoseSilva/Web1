<?php
    include_once("ConnectionFactory_class.php"); //PDO
    include_once("Contato_class.php"); //Entidade

    class ContatoDAO{
        //DAO
        //CRUD
        //Operações básicas de banco de dados
        
        public $con = null;

        public function __construct(){
            $conF = new ConnectionFactory();
            $this->con = $conF->getConnection();
        }
    }
?>